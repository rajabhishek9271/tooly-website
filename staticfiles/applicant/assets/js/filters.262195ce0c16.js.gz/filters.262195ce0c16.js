$(document).ready(function(){
    $("#type").on("change", "input:checkbox", function(){
        $("#type").submit();
    });
});

console.log("JJHO");
